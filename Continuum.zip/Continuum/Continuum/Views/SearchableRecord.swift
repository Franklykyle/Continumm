//
//  SearchableRecord.swift
//  Continuum
//
//  Created by Kyle Franklin on 8/12/21.
//

import Foundation

protocol SearchableRecord {
    func matches (searchTerm: String) -> Bool
}
