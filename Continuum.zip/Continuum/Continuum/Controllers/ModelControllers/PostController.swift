//
//  PostController.swift
//  Continuum
//
//  Created by Kyle Franklin on 8/10/21.
//

import UIKit
import CloudKit

class PostController {
    
    static let shared = PostController()
    private init() {}
    
    var posts: [Post] = []
    


func addComment(text: String, post: Post, completion: @escaping (Result<Comment?, PostError>) -> Void) {
    let comment = Comment(text: text)
    post.comments.append(comment)
    
}

func createPostWith(photo: UIImage, caption: String, completion: @escaping (Result<Post?, PostError>) -> Void) {
    let post = Post(photo: photo, caption: caption)
    posts.append(post)
}
}
