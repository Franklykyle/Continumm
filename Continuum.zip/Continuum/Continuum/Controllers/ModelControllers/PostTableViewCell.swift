//
//  PostTableViewCell.swift
//  Continuum
//
//  Created by Kyle Franklin on 8/10/21.
//

import UIKit

class PostTableViewCell: UITableViewCell {
    
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var captionTextLabel: UILabel!
    @IBOutlet weak var commentTextLabel: UILabel!
    
    var post: Post? {
        didSet {
            updateViews()
        }
        
    }
    func updateViews() {
        
        photoImageView.image = post?.photo
        captionTextLabel.text = post?.caption
        commentTextLabel.text = "Comments: \(post?.comments.count ?? 0)"
    }

}
