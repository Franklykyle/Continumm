//
//  PhotoSelectorViewController.swift
//  Continuum
//
//  Created by Kyle Franklin on 8/12/21.
//

import UIKit

class PhotoSelectorViewController: UIViewController {
    
    @IBOutlet weak var selectPhotoButton: PhotoSelectorViewController!
    
    @IBOutlet weak var photoImageView: UIImageView!
    
    @IBOutlet weak var selectPhotoButtonTapped: PhotoSelectorViewController!
    
    weak var delegate: PhotoSelectorViewControlleDelegate?
}

protocol PhotoSelectorViewControlleDelegate: class {
    func 
}
