//
//  addPostTableViewController.swift
//  Continuum
//
//  Created by Kyle Franklin on 8/10/21.
//

import UIKit

class addPostTableViewController: UITableViewController {
    
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var selectPhotoButton: UIButton!
    @IBOutlet weak var captionTextField: UITextField!
    
    var selectedImage: UIImage?
    
    

    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        captionTextField.text = nil
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
      if segue.identifier == "toPhotoSelectorVC" {
        let photoSelector = segue.destination as? PhotoSelectorViewController
        photoSelector?.delegate = self
      }
    }
    
    @IBAction func selectPhotoButton(_ sender: UIButton) {
        guard let photo = selectedImage,
              let caption = captionTextField.text else { return }
        PostController.shared.createPostWith(photo: photo, caption: caption) { (post) in
            
        }
        self.tabBarController?.selectedIndex = 0
    }
    
    
    
    @IBAction func addPostButtonTapped(_ sender: UIButton) {
        guard let photo = photoImageView.image,
              let caption = captionTextField.text else { return }
        PostController.shared.createPostWith(photo: photo, caption: caption) { (post) in

        }
        self.tabBarController?.selectedIndex = 0
        
    }
    @IBAction func cancelButtonTapped(_ sender: Any) {
        self.tabBarController?.selectedIndex = 0
    }
}

extension addPostTableViewController: PhotoSelectorViewControllerDelegate {
    func photoSelectorViewControllerSelected(image: UIImage) {
        selectedImage = image
    }
}

